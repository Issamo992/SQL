SELECT cust.CustomerId, cust.CustomerName FROM
(SELECT Pr.CustomerId, COUNT(Pr.CustomerId) AS prdCount, SUM(Pr.Qty) AS sumQty
	FROM dbo.Product AS prd
	INNER JOIN dbo.Purchase Pr
	ON prd.ProductId = pr.ProductId
	GROUP BY  pr.CustomerId
	HAVING SUM(pr.Qty)>50
) AS cq
INNER JOIN (SELECT COUNT(*) AS pdCount FROM dbo.Product) AS pcnt
ON pcnt.pdCount=cq.prdCount
INNER JOIN dbo.Customer cust ON cq.CustomerId=cust.CustomerId