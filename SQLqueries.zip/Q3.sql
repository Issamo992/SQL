USE [WideWorldImporters]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[ReportCustomerTurnover]
@in_choice INT = 1,
@in_year INT =2013
AS
BEGIN
IF @in_choice=1
BEGIN

SELECT sc.CustomerName, FORMAT(TransactionDate, 'MMM') AS Month_, SUM(AmountExcludingTax) AS AmountExcludingTaxes
FROM Sales.Customers sc
INNER JOIN Sales.CustomerTransactions SCT
ON sc.customerID = SCT.CustomerID
WHERE YEAR(TransactionDate)=@in_year
GROUP BY sc.CustomerName, FORMAT(TransactionDate, 'MMM')

END

IF @in_choice=2
BEGIN
     
SELECT sc.CustomerName, DATEPART(QUARTER, TransactionDate) AS Quarter_, SUM(AmountExcludingTax) AS AmountExcludingTax from Sales.Customers sc
INNER JOIN
Sales.CustomerTransactions SCT
ON sc.CustomerID = SCT.CustomerID
WHERE YEAR(TransactionDate)=@in_year
GROUP BY sc.CustomerName, DATEPART(QUARTER, TransactionDate)    

END
     
IF @in_choice=3
BEGIN
SELECT sc.CustomerName, YEAR (TransactionDate) as Year_, SUM(AmountExcludingTax) AS AmountExcludingTax FROM Sales.Customers sc
INNER JOIN Sales.CustomerTransactions sct
ON sc.CustomerID = sct.CustomerID
GROUP BY sc.CustomerName, year(TransactionDate)
     
END

END

GO

EXEC dbo.ReportCustomerTurnover;
EXEC dbo.ReportCustomerTurnover 1, 2014;
EXEC dbo.ReportCustomerTurnover 2, 2015;
EXEC dbo.ReportCustomerTurnover 3;