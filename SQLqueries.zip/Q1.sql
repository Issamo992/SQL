DROP VIEW Invoice_Amount

CREATE VIEW Invoice_Amount
AS
(SELECT si.InvoiceID, SUM(sil.UnitPrice*sil.Quantity) as I_Amount
FROM sales.Invoices si, sales.InvoiceLines sil
WHERE si.invoiceID=sil.InvoiceID
GROUP BY si.InvoiceID)

DROP VIEW Order_Amount

CREATE VIEW Order_Amount
AS
(SELECT so.orderID, SUM(sol.UnitPrice*sol.Quantity) as O_Amount
FROM sales.orders so, sales.OrderLines sol
WHERE so.OrderID=sol.OrderID
GROUP BY so.OrderID)

SELECT DISTINCT sc.CustomerID, sc.CustomerName, COUNT (so.OrderID) as TotalNBOrders, COUNT(si.InvoiceID) as TotalNBInvoices, SUM(om.O_Amount) AS OrdersTotalValue, SUM(ia.I_Amount) AS InvoicesTotalValue, ABS(SUM(om.O_Amount)-SUM(ia.I_Amount)) as AbsoluteValueDifference
FROM Sales.Customers sc
JOIN Sales.Orders so
	ON sc.CustomerID = so.CustomerID
JOIN Sales.Invoices si
	ON so.OrderID = si.OrderID 
JOIN dbo.Order_Amount om
	ON so.OrderID = om.OrderID
JOIN dbo.Invoice_Amount ia
	ON si.InvoiceID = ia.InvoiceID
WHERE so.orderid in (
	SELECT orderID
	FROM Sales.Invoices)
GROUP BY sc.CustomerID, sc.CustomerName
ORDER BY sc.CustomerID