UPDATE Sales.InvoiceLines
SET UnitPrice = UnitPrice +20
WHERE InvoiceLineID = (SELECT min(InvoiceLineID) FROM Sales.InvoiceLines WHERE InvoiceID =
																							(Select min(InvoiceID)
																							FROM Sales.Invoices WHERE CustomerID=1060));

SELECT DISTINCT sc.CustomerID, sc.CustomerName, COUNT (so.OrderID) as TotalNBOrders, COUNT(si.InvoiceID) as TotalNBInvoices, SUM(om.O_Amount) AS OrdersTotalValue, SUM(ia.I_Amount) AS InvoicesTotalValue, ABS(SUM(om.O_Amount)-SUM(ia.I_Amount)) as AbsoluteValueDifference
FROM Sales.Customers sc
JOIN Sales.Orders so
	ON sc.CustomerID = so.CustomerID
JOIN Sales.Invoices si
	ON so.OrderID = si.OrderID 
JOIN dbo.Order_Amount om
	ON so.OrderID = om.OrderID
JOIN dbo.Invoice_Amount ia
	ON si.InvoiceID = ia.InvoiceID
WHERE so.orderid in (
	SELECT orderID
	FROM Sales.Invoices)
GROUP BY sc.CustomerID, sc.CustomerName
ORDER BY AbsoluteValueDifference DESC